﻿$axure.loadCurrentPage(
    (function () {
        var _ = function () {
            var r = {}, a = arguments;
            for (var i = 0; i < a.length; i += 2) r[a[i]] = a[i + 1];
            return r;
        }
        var _creator = function () {
            return _(b, c, d, e, f, _(g, h, i, _(j, k, l, m)), n, [], o, _(h, p), q, [r, s], t, _(u, v, w, x, g, y, z, _(), A, [], B, _(C, D, E, F, G, _(H, I, J, K), L, null, M, _(N, O, P, O), Q, R, S, null, T, U, V, W, X, Y, Z, U, ba, bb, bc, _(H, I, J, bd), be, U, bf, bb, bg, _(bh, bi, bj, bk, bl, bk, bm, bk, bn, m, J, _(bo, bp, bq, bp, br, bp, bs, bt)), i, _(j, m, l, m)), bu, _(), bv, _(), bw, _(bx, [_(by, bz, bA, h, bB, bC, w, bD, bE, bD, bF, bG, B, _(X, bH, bI, bJ, bK, bL, bM, bN, bO, _(H, I, J, bP, bQ, bR), i, _(j, bS, l, bS), C, bT, bU, _(bV, bW, bX, bY), bc, _(H, I, J, bZ), ca, cb, cc, cd, ce, cf, be, cg), bu, _(), ch, _(), ci, bi, cj, bi, ck, bi), _(by, cl, bA, h, bB, cm, w, cn, bE, cn, bF, bG, B, _(X, co, bI, bJ, bK, bL, bM, bN, bO, _(H, I, J, cp, bQ, bR), bU, _(bV, bR, bX, cq), i, _(j, k, l, cr)), bu, _(), ch, _(), cs, ct), _(by, cu, bA, h, bB, cv, w, cw, bE, cw, bF, bG, B, _(X, co, bI, bJ, bK, bL, bM, bN, bO, _(H, I, J, cp, bQ, bR), bU, _(bV, m, bX, m)), bu, _(), ch, _(), cx, [_(by, cy, bA, h, bB, bC, w, bD, bE, bD, bF, bG, B, _(X, cz, bO, _(H, I, J, cA, bQ, bR), bI, bJ, bK, bL, bM, bN, i, _(j, cr, l, cr), C, bT, bU, _(bV, cB, bX, cC), cD, cE, ce, cF, Z, U, G, _(H, I, J, cG)), bu, _(), ch, _(), ci, bi, cj, bi, ck, bi), _(by, cH, bA, h, bB, bC, w, bD, bE, bD, bF, bG, B, _(X, bH, bI, bJ, bO, _(H, I, J, cI, bQ, bR), bK, bL, bM, bN, bU, _(bV, cJ, bX, cK), i, _(j, cL, l, cM), cD, cN, ce, cO, C, bT, ca, F, G, _(H, I, J, cG), Z, U, cP, cQ), bu, _(), ch, _(), ci, bi, cj, bi, ck, bi), _(by, cR, bA, h, bB, bC, w, bD, bE, bD, bF, bG, B, _(X, cS, bI, cT, bO, _(H, I, J, bP, bQ, bR), bK, bL, bM, bN, i, _(j, cL, l, cM), cD, cU, ce, cU, C, bT, bU, _(bV, cJ, bX, cV), ca, F, G, _(H, I, J, cG), Z, U, cP, cQ), bu, _(), ch, _(), ci, bi, cj, bi, ck, bi)], cW, bi), _(by, cX, bA, h, bB, bC, w, bD, bE, bD, bF, bG, B, _(X, bH, bI, bJ, bO, _(H, I, J, cY, bQ, bR), bK, bL, bM, bN, i, _(j, cZ, l, cM), C, bT, bc, _(H, I, J, cY), Z, da, db, _(dc, _(bQ, dd), de, _(bQ, da)), bU, _(bV, df, bX, dg), be, dh, G, _(H, I, J, cG)), bu, _(), ch, _(), bv, _(di, _(dj, dk, dl, dm, dn, [_(dl, h, dp, h, dq, bi, dr, ds, dt, [_(du, dv, dl, dw, dx, dy, dz, _(dA, _(h, dw)), dB, _(dC, t, b, dD, dE, bG), dF, dG)])])), dH, bG, ci, bi, cj, bi, ck, bi)])), dI, _(dJ, _(u, dJ, w, dK, g, cm, z, _(), A, [], B, _(C, D, E, F, G, _(H, I, J, dL), L, null, M, _(N, O, P, O), Q, R, S, null, T, U, V, W, X, Y, Z, U, ba, bb, bc, _(H, I, J, bd), be, U, bf, bb, bg, _(bh, bi, bj, bk, bl, bk, bm, bk, bn, m, J, _(bo, bp, bq, bp, br, bp, bs, bt)), i, _(j, m, l, m)), n, [], bv, _(), bw, _(bx, [_(by, dM, bA, h, bB, bC, w, bD, bE, bD, bF, bG, B, _(X, bH, bI, bJ, bO, _(H, I, J, dN, bQ, bR), bK, bL, bM, bN, i, _(j, k, l, cr), C, bT, ce, cU, ba, cQ, bc, _(H, I, J, dO), G, _(H, I, J, cG), dP, dQ, cD, dR), bu, _(), ch, _(), bx, [_(by, dS, bA, h, bB, dT, w, dU, bE, dU, bF, bG, B, _(bO, _(H, I, J, dN, bQ, bR), X, bH, bI, bJ, bK, bL, bM, bN, C, dV, db, _(dc, _(bO, _(H, I, J, dN, bQ, bR)), de, _()), cD, dR), bu, _(), ch, _(), bv, _(di, _(dj, dk, dl, dm, dn, [_(dl, h, dp, h, dq, bi, dr, ds, dt, [_(du, dv, dl, dW, dx, dy, dz, _(dX, _(h, dW)), dB, _(dC, dY, dZ, _(ea, eb, ec, ed, ee, []), dE, bi), dF, ef)])])), dH, bG), _(by, dS, bA, h, bB, dT, w, dU, bE, dU, bF, bG, B, _(bO, _(H, I, J, dN, bQ, bR), X, bH, bI, bJ, bK, bL, bM, bN, C, dV, db, _(dc, _(bO, _(H, I, J, dN, bQ, bR)), de, _()), cD, dR), bu, _(), ch, _(), bv, _(di, _(dj, dk, dl, dm, dn, [_(dl, h, dp, h, dq, bi, dr, ds, dt, [_(du, dv, dl, dW, dx, dy, dz, _(dX, _(h, dW)), dB, _(dC, dY, dZ, _(ea, eb, ec, ed, ee, []), dE, bi), dF, ef)])])), dH, bG)], eg, _(eh, ei), ci, bi, cj, bi, ck, bi)]))), ej, _(ek, _(el, em), en, _(el, eo, ep, _(el, eq), er, _(el, es)), et, _(el, eu), ev, _(el, ew), ex, _(el, ey), ez, _(el, eA), eB, _(el, eC)));
        };
        var b = "url", c = "registerwin.html", d = "generationDate", e = new Date(1681470065350.1277),
            f = "defaultAdaptiveView", g = "name", h = "", i = "size", j = "width", k = 1200, l = "height", m = 0,
            n = "adaptiveViews", o = "sketchKeys", p = "s0", q = "variables", r = "OnLoadVariable", s = "Login",
            t = "page", u = "packageId", v = "b9f2deb07b14401aa0496e2427cbfe40", w = "type", x = "Axure:Page",
            y = "registerWin", z = "notes", A = "annotations", B = "style", C = "baseStyle",
            D = "627587b6038d43cca051c114ac41ad32", E = "pageAlignment", F = "center", G = "fill", H = "fillType",
            I = "solid", J = "color", K = 0xFFF0F2F5, L = "image", M = "imageAlignment", N = "horizontal", O = "near",
            P = "vertical", Q = "imageRepeat", R = "auto", S = "favicon", T = "sketchFactor", U = "0", V = "colorStyle",
            W = "appliedColor", X = "fontName", Y = "Applied Font", Z = "borderWidth", ba = "borderVisibility",
            bb = "all", bc = "borderFill", bd = 0xFF797979, be = "cornerRadius", bf = "cornerVisibility",
            bg = "outerShadow", bh = "on", bi = false, bj = "offsetX", bk = 5, bl = "offsetY", bm = "blurRadius",
            bn = "spread", bo = "r", bp = 0, bq = "g", br = "b", bs = "a", bt = 0.34901960784313724,
            bu = "adaptiveStyles", bv = "interactionMap", bw = "diagram", bx = "objects", by = "id",
            bz = "9c994b7485f646f1b32024bdbd8206e6", bA = "label", bB = "friendlyType", bC = "矩形", bD = "vectorShape",
            bE = "styleType", bF = "visible", bG = true, bH = "'微软雅黑', sans-serif", bI = "fontWeight", bJ = "400",
            bK = "fontStyle", bL = "normal", bM = "fontStretch", bN = "5", bO = "foreGroundFill", bP = 0xFF666666,
            bQ = "opacity", bR = 1, bS = 460, bT = "4b7bfc596114427989e10bb0b557d0ce", bU = "location", bV = "x",
            bW = 421, bX = "y", bY = 120, bZ = 0xFFE9E9E9, ca = "horizontalAlignment", cb = "left", cc = "paddingLeft",
            cd = "20", ce = "lineSpacing", cf = "20px", cg = "10", ch = "imageOverrides", ci = "generateCompound",
            cj = "autoFitWidth", ck = "autoFitHeight", cl = "40dc9220897542138d5d861c523db8b5", cm = "精简底部",
            cn = "referenceDiagramObject", co = "'Arial Normal', 'Arial', sans-serif", cp = 0xFF333333, cq = 640,
            cr = 100, cs = "masterId", ct = "6d609135c2694b05bfd8bccc09cce47d", cu = "22c5fec2b4d04e6b8c448f6ea2b17df5",
            cv = "组合", cw = "layer", cx = "objs", cy = "1a66f87bbbfc41fe8a4b7bebeb762cd2",
            cz = "'FontAwesome', sans-serif", cA = 0xFF4BD863, cB = 601, cC = 230, cD = "fontSize", cE = "100px",
            cF = "120px", cG = 0xFFFFFF, cH = "c22e5c6caca74c66ac6d2c70f3c8ac8f", cI = 0xFF999999, cJ = 301, cK = 380,
            cL = 700, cM = 40, cN = "14px", cO = "22px", cP = "verticalAlignment", cQ = "top",
            cR = "5573a57e19144f649c72a081ec7c71c3", cS = "'微软雅黑 Bold', '微软雅黑', '微软雅黑', sans-serif",
            cT = "700", cU = "24px", cV = 340, cW = "propagate", cX = "ab20b4b6f92144259d77235d16b2d2fa",
            cY = 0xFF0079FE, cZ = 150, da = "1", db = "stateStyles", dc = "mouseOver", dd = "0.8", de = "mouseDown",
            df = 576, dg = 440, dh = "3", di = "onClick", dj = "eventType", dk = "OnClick", dl = "description",
            dm = "单击", dn = "cases", dp = "conditionString", dq = "isNewIfGroup", dr = "caseColorHex", ds = "AB68FF",
            dt = "actions", du = "action", dv = "linkWindow", dw = "在 当前窗口 打开 index", dx = "displayName",
            dy = "打开链接", dz = "actionInfoDescriptions", dA = "index", dB = "target", dC = "targetType", dD = "",
            dE = "includeVariables", dF = "linkType", dG = "current", dH = "tabbable", dI = "masters",
            dJ = "6d609135c2694b05bfd8bccc09cce47d", dK = "Axure:Master", dL = 0xFFFFFFFF,
            dM = "16a19156fa9146a498eb0f2fb4888dcf", dN = 0xFFCCCCCC, dO = 0xFF34495E, dP = "linePattern", dQ = "none",
            dR = "12px", dS = "b22be03382854ba98b81ad93bc23b0bd", dT = "文本链接", dU = "hyperlink",
            dV = "2e6beb85ee6a4d068795f484f2d6f09e", dW = "在 新窗口/标签页 打开 https://www.axureshop.com/shop/184",
            dX = "https://www.axureshop.com/shop/184 in 新窗口/标签页", dY = "webUrl", dZ = "urlLiteral",
            ea = "exprType", eb = "stringLiteral", ec = "value", ed = "https://www.axureshop.com/shop/184", ee = "stos",
            ef = "new", eg = "images", eh = "u1017~normal~", ei = "images/register/u968.svg", ej = "objectPaths",
            ek = "9c994b7485f646f1b32024bdbd8206e6", el = "scriptId", em = "u1015",
            en = "40dc9220897542138d5d861c523db8b5", eo = "u1016", ep = "16a19156fa9146a498eb0f2fb4888dcf",
            eq = "u1017", er = "b22be03382854ba98b81ad93bc23b0bd", es = "u1018",
            et = "22c5fec2b4d04e6b8c448f6ea2b17df5", eu = "u1019", ev = "1a66f87bbbfc41fe8a4b7bebeb762cd2",
            ew = "u1020", ex = "c22e5c6caca74c66ac6d2c70f3c8ac8f", ey = "u1021",
            ez = "5573a57e19144f649c72a081ec7c71c3", eA = "u1022", eB = "ab20b4b6f92144259d77235d16b2d2fa",
            eC = "u1023";
        return _creator();
    })());